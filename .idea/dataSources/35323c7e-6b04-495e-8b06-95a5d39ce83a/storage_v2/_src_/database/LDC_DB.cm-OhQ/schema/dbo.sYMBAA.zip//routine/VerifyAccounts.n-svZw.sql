-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[VerifyAccounts]
	-- Add the parameters for the stored procedure here
	@wOpenid VARCHAR(50),
	@wNickname VARCHAR(50),
	@wSex TINYINT,
	@wHeadimgurl VARCHAR(MAX),
	@wIp VARCHAR(30)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @wUserID INT
	DECLARE @regGrantCard BIGINT
	DECLARE @state INT
    -- Insert statements for procedure here
	SELECT @state = StatusValue FROM SystemStatusInfo WHERE StatusName = 'LoginEnable';
	IF (@state = 1)
		RETURN 1;
	IF NOT EXISTS (SELECT userid FROM dbo.user_info WHERE openid = @wOpenid)
		BEGIN
			SELECT @regGrantCard = StatusValue FROM dbo.SystemStatusInfo WHERE StatusName = N'GrantCardCount'
			INSERT INTO dbo.user_info
			        (
			          openid ,
			          nickname ,
			          gender ,
			          avatar ,
			          ip ,
			          nullity ,
			          card ,
					  lockcard,
			          gold ,
			          score ,
			          win_count ,
			          lose_count ,
			          draw_count ,
			          flee_count ,
			          loggedIn ,
			          RegisterDate ,
			          LastLogonDate ,
			          LastLogoutDate
			        )
			VALUES  (
			          @wOpenid , -- openid - varchar(50)
			          @wNickname , -- nickname - varchar(50)
			          @wSex , -- gender - tinyint
			          @wHeadimgurl , -- avatar - varchar(100)
			          @wIp , -- ip - varchar(30)
			          0 , -- nullity - tinyint
			          @regGrantCard , -- card - bigint
					  0,
			          0 , -- gold - bigint
			          0 , -- score - bigint
			          0 , -- win_count - int
			          0 , -- lose_count - int
			          0 , -- draw_count - int
			          0 , -- flee_count - int
			          0 , -- loggedIn - tinyint
			          GETDATE() , -- RegisterDate - datetime
			          NULL , -- LastLogonDate - datetime
			          NULL  -- LastLogoutDate - datetime
			        )
		END
	ELSE
		BEGIN
			UPDATE dbo.user_info SET nickname = @wNickname,gender = @wSex,avatar=@wHeadimgurl,ip=@wIp  WHERE openid = @wOpenid
		END

	DECLARE @UserID INT
	DECLARE @Nickname VARCHAR(50)
	DECLARE @Sex TINYINT
	DECLARE @FaceUrl VARCHAR(MAX)
	DECLARE @IP VARCHAR(30)
	DECLARE @Nullity TINYINT
	DECLARE @card BIGINT
	DECLARE @gold BIGINT
	DECLARE @parentId INT


	SELECT @UserID=UserID,@Nickname=nickname,@Sex=gender,@FaceUrl=avatar,@IP=ip,@Nullity=Nullity,@card=card,@gold=gold,@parentId=parentId FROM dbo.user_info WHERE openid = @wOpenid
	SELECT @UserID AS userid,@Nickname AS nickname,@sex AS sex,@FaceUrl AS faceurl,@IP AS ip,@card AS card,@gold AS gold,@parentId AS parentId,@Nullity AS nullity
	RETURN 0;
END
GO

