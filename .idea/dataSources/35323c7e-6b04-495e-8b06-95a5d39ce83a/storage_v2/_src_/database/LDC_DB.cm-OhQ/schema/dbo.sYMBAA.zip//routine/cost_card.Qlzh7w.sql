-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cost_card]
	-- Add the parameters for the stored procedure here
	@uuid VARCHAR(150),
	@uid INT,
	@cost BIGINT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE dbo.user_info SET card = card - @cost,lockcard=lockcard - @cost WHERE userid=@uid AND card>=@cost AND lockcard>=@cost
	IF(@@ERROR=0 AND @@ROWCOUNT=1)
	BEGIN
		UPDATE card_room SET deducted = 1 WHERE uuid=@uuid
		RETURN 0;
	END
	RETURN -1;
END
GO

