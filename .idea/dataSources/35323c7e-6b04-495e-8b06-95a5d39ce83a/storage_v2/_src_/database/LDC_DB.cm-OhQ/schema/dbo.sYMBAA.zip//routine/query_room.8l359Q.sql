-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[query_room] 
	-- Add the parameters for the stored procedure here
	@num INT OUTPUT,
	@page INT OUTPUT,
	@uid INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @tPage INT
	DECLARE @begin INT
	DECLARE @end INT

    -- Insert statements for procedure here
	SELECT @num=COUNT(*) FROM dbo.card_room WHERE owner=@uid
	IF(@page<0)
		SELECT @page=0
	IF(@num=0)
		SELECT @page=0,@begin=0,@end=0
	ELSE
	BEGIN
		SELECT @tPage=(@num-1)/10+1
		IF(@page>@tPage)
			SELECT @page=@tPage;
		SELECT @begin=10,@end=@page*10
		IF(@end>@num)
		BEGIN
			SELECT @begin=@num%10
			SELECT @end=@num
		END
	END
	SELECT TOP (@begin) * FROM (SELECT TOP (@end) * FROM (SELECT * FROM dbo.card_room WHERE owner=@uid)t ORDER BY t.create_time ASC)ta ORDER BY ta.create_time DESC
END
GO

