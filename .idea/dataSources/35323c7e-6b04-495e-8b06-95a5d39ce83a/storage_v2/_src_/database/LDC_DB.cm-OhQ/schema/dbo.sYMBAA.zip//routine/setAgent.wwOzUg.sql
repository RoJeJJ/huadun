-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[setAgent] 
	-- Add the parameters for the stored procedure here
	@uid INT,
	@agentId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @id INT
	DECLARE @err INT

    SELECT @id=0
	SELECT @err=1
	SELECT @id=id FROM xy_agent WHERE snid=@agentId
	UPDATE dbo.user_info SET parentId=@id WHERE @id!=0 AND userid=@uid AND parentId=0
	IF(@@ERROR=0 AND @@ROWCOUNT=1)
		SELECT @err = 0
	SELECT @err AS err,@id AS pid;
END
GO

